package com.ibm.fsd.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ibm.fsd.model.MentorCalendar;

public interface MentorCalendarRepository extends JpaRepository<MentorCalendar, Long> {}
