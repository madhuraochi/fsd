package com.ibm.fsd.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
@Table(name = "mentor")
public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "user_name", nullable = false)
	private String userName;

	@Column(name = "password", nullable = false)
	private String password;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "mentor")
	@JsonManagedReference(value = "mentor-mentorSkills")
	private Set<MentorSkills> mentorSkills = new HashSet<>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "mentor")
	@JsonManagedReference(value = "mentor-mentorCalendars")
	private Set<MentorCalendar> mentorCalendars = new HashSet<>();

	@Column(name = "linkedin_url", nullable = false)
	private String linkedinUrl;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "reg_date_time", nullable = false)
	private Date regDateTime;

	@Column(name = "reg_code", nullable = false)
	private String regCode;

	@Column(name = "years_of_experience", nullable = false)
	private Float yearsOfExperience;

	@Column(name = "active", nullable = false)
	private Boolean active = true;
//
//	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "mentor")
//	@JsonManagedReference(value = "mentor-role")
//	private Role role;
	
	public Mentor(String userName, String password, String linkedinUrl, Date regDateTime, String regCode, Float yearsOfExperience, Boolean active) {
    	this.userName = userName;
    	this.password = password;
        this.linkedinUrl = linkedinUrl;
        this.regDateTime = regDateTime;
        this.regCode = regCode;
        this.yearsOfExperience = yearsOfExperience;
        this.active = active;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<MentorSkills> getMentorSkills() {
		return mentorSkills;
	}

	public void setMentorSkills(Set<MentorSkills> mentorSkills) {
		this.mentorSkills = mentorSkills;
	}


	public String getLinkedinUrl() {
		return linkedinUrl;
	}

	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}

	public Date getRegDateTime() {
		return regDateTime;
	}

	public void setRegDateTime(Date regDateTime) {
		this.regDateTime = regDateTime;
	}

	public String getRegCode() {
		return regCode;
	}

	public void setRegCode(String regCode) {
		this.regCode = regCode;
	}

	public Float getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(Float yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Set<MentorCalendar> getMentorCalendars() {
		return mentorCalendars;
	}

	public void setMentorCalendars(Set<MentorCalendar> mentorCalendars) {
		this.mentorCalendars = mentorCalendars;
	}
}
