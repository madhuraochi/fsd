package com.ibm.fsd.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ibm.fsd.model.MentorSkills;


public interface MentorSkillsRepository extends JpaRepository<MentorSkills, Long> {}
