package com.ibm.fsd.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "mentor_skills")
public class MentorSkills {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "mentor_id", nullable = false)
	@JsonBackReference(value = "mentor-mentorSkills")
	private Mentor mentor;

//	@OneToOne(fetch = FetchType.LAZY, optional = false)
//	@JoinColumn(name = "skill_id", nullable = false)
//	@JsonBackReference(value ="skill-mentorSkills")
//	private Skill skill;

	@Column(name = "self_rating", nullable = false)
	private Double selfRating;

	@Column(name = "years_of_exp", nullable = false)
	private Double yearsOfExp;

	@Column(name = "tarinings_delivered", nullable = false)
	private Integer tariningsDelivered;

	@Column(name = "facilities_offered", nullable = false)
	private String facilitiesOffered;
	
	
	public MentorSkills(Double selfRating, Integer tariningsDelivered, String facilitiesOffered) {
    	this.selfRating = selfRating;
    	this.tariningsDelivered = tariningsDelivered;
        this.facilitiesOffered = facilitiesOffered;
    }
}
