package com.ibm.fsd.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "payments")
public class Payments {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "mentor_id", nullable = true)
	private Long mentorId;

	@Column(name = "training_id", nullable = true)
	private Long trainingId;

	@Column(name = "txn_type", nullable = true)
	private String txnType;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "txn_date_time", nullable = true)
	private Date dateTime;

	@Column(name = "txn_status", nullable = true)
	private String txnStatus;

	@Column(name = "amount", nullable = false)
	private Double amount;

	@Column(name = "remarks", nullable = false)
	private String remarks;
	
	
	public Payments() {
		super();
	}
	
	public Payments(Long mentorId, Long trainingId, String txnType, Date dateTime, String txnStatus, Double amount, String remarks) {
		super();
		this.mentorId = mentorId;
		this.trainingId = trainingId;
		this.txnType = txnType;
		this.dateTime = dateTime;
		this.txnStatus = txnStatus;
		this.amount = amount;
		this.remarks = remarks;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public Long getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(Long trainingId) {
		this.trainingId = trainingId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
