package com.ibm.fsd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.fsd.model.Trainings;
import com.ibm.fsd.service.TrainingService;


@RestController
@RequestMapping("/training")
public class TrainingController {

	@Autowired
	private TrainingService trainingService;

	@GetMapping("/trainingById/{trainingId}")
	public Trainings getTrainingDetails(@PathVariable(value = "trainingId", required = true) Long trainingId) {
		return trainingService.findByTrainingId(trainingId);
	}

	@GetMapping("/trainingByStatus/{userId}/{status}")
	public List<Trainings> getTrainingsByStatus(@PathVariable(value = "userId", required = true) Long userId, @PathVariable(value = "status", required = true) String status) {
		return trainingService.getTrainingsByStatus(userId, status);
	}
	
	@PostMapping("/addTraining")
	public ResponseEntity<?> createTraining(@RequestBody Trainings training) {
		trainingService.addTraining(training);
		return ResponseEntity.ok("Training added successfully");
	}

	@PutMapping("/updateTraining/{trainingId}/{status}")
	public ResponseEntity<?> updateTrainingStatus(@PathVariable(value = "trainingId", required = true) Long trainingId, @PathVariable(value = "status", required = true) String status) {
		trainingService.updateTrainingStatus(trainingId, status);
		return ResponseEntity.ok("Training updated successfully");
	}
}