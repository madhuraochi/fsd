package com.ibm.fsd.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ibm.fsd.model.Trainings;


public interface TrainingRepository extends JpaRepository<Trainings, Long> {
	
	@Query(value = "SELECT t FROM trainings t where t.userId=:userId and t.status=:status")
	List<Trainings> findTrainingsByStatus(@Param("userId") Long userId, @Param("status") String status);
	
	@Query(value = "SELECT t FROM trainings t where t.userId=:userId and t.mentorId=:mentorId and t.skillId=:skillId and t.status=:status") 
	List<Trainings> findTraining(@Param("userId") Long userId,@Param("mentorId") Long mentorId, @Param("skillId") Long skillId, @Param("status") String status);
}
