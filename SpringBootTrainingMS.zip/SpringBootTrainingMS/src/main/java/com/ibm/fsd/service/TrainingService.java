package com.ibm.fsd.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.fsd.exception.ResourceExistException;
import com.ibm.fsd.exception.ResourceNotFoundException;
import com.ibm.fsd.model.Trainings;
import com.ibm.fsd.repository.TrainingRepository;

@Service
@Transactional(readOnly = true)
public class TrainingService {

	@Autowired
	private TrainingRepository trainingRepo;
	
	public Trainings findByTrainingId(Long id) {
		return Optional.ofNullable(trainingRepo.findById(id).get())
				.orElseThrow(() -> new ResourceNotFoundException("Training Id " + id + " not found"));
	}

	public Trainings addTraining(Trainings trainings) {
		List<Trainings> lt = trainingRepo.findTraining(trainings.getUserId(), trainings.getMentorId(), trainings.getSkillId(), trainings.getStatus());
		if(lt.size()>0){
			throw new ResourceExistException("The Training details are already Exists");
		}
		trainingRepo.save(trainings);
		return trainings;
	}
	
	public List<Trainings> getTrainingsByStatus(Long userId, String status){
		return Optional.ofNullable(trainingRepo.findTrainingsByStatus(userId, status))
				.orElseThrow(() -> new ResourceNotFoundException("User Id " + userId + " not found"));
	}

	public Trainings updateTrainingStatus(Long id, String status) {
		return trainingRepo.findById(id).map(prevTraining -> {
			prevTraining.setStatus(status);
			return trainingRepo.save(prevTraining);
		}).orElseThrow(() -> new ResourceNotFoundException("Training Id " + id + " not found"));
	}
}
