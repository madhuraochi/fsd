package com.ibm.fsd.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ibm.fsd.model.Constants.TrainingStatus;

@Entity
@Table(name = "trainings")
public class Trainings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "user_id")
	private Long userId;
	
	@Column(name = "mentor_id")
	private Long mentorId;

	@Column(name = "skill_id")
	private Long skillId;

	@Column(name = "status", nullable = false)
	private String status = TrainingStatus.PROPOSED.getStatus();

	@Column(name = "progress")
	private Integer progress = 0;

	@Column(name = "rating")
	private Double rating = 0.0d;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "start_date", nullable = false)
	private String startDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "end_date", nullable = false)
	private String endDate;

	@JsonFormat(pattern = "HH:mm:ss")
	@Column(name = "start_time", nullable = false)
	private String startTime;

	@JsonFormat(pattern = "HH:mm:ss")
	@Column(name = "end_time", nullable = false)
	private String endTime;

	@Column(name = "amount_received", nullable = false)
	private Double amountReceived = 0.0d;

	
	public Trainings() {
		super();
	}

	public Trainings(Long userId, Long mentorId, Long skillId, Integer progress,String startDate, String endDate, String startTime, String endTime) {
		super();
		this.userId = userId;
		this.mentorId = mentorId;
		this.skillId = skillId;
		this.progress = progress;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public Long getSkillId() {
		return skillId;
	}

	public void setSkillId(Long skillId) {
		this.skillId = skillId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getProgress() {
		return progress;
	}

	public void setProgress(Integer progress) {
		this.progress = progress;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Double getAmountReceived() {
		return amountReceived;
	}

	public void setAmountReceived(Double amountReceived) {
		this.amountReceived = amountReceived;
	}
}
