package com.ibm.fsd.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.fsd.exception.ResourceExistException;
import com.ibm.fsd.exception.ResourceNotFoundException;
import com.ibm.fsd.model.Technology;
import com.ibm.fsd.repository.TechnologyRepository;

@Service
@Transactional(readOnly = true)
public class TechnologyService {

	@Autowired
	private TechnologyRepository techRepository;

	public List<Technology> findAllTechnologies() {
		return techRepository.findAll();
	}

	public Technology findByTechlId(Long techId) {
		return Optional.ofNullable(techRepository.findById(techId).get())
				.orElseThrow(() -> new ResourceNotFoundException("Tech Id " + techId + " not found"));
	}

	public List<Technology> findByTechName(String techName) {
		return Optional.ofNullable(techRepository.findByName(techName))
				.orElseThrow(() -> new ResourceNotFoundException("Tech Name " + techName + " not found"));
	}

	public Technology addTechnology(Technology tech) {
		if (!techRepository.findByName(tech.getName()).isEmpty())
			throw new ResourceExistException("Tech Name " + tech.getName() + " already Exists");
		
		techRepository.save(tech);
		return tech;
	}

	public Technology updateTechnology(Long techId, Technology tech) {
		return techRepository.findById(techId).map(prevTech -> {
			prevTech.setName(tech.getName());
			prevTech.setToc(tech.getToc());
			prevTech.setPrerequisites(tech.getPrerequisites());
			return techRepository.save(prevTech);
		}).orElseThrow(() -> new ResourceNotFoundException("Tech Id " + techId + " not found"));
	}

	public void deleteTechnology(Long techId) {
		techRepository.findById(techId).map(tech -> {
			techRepository.delete(tech);
			return true;
		}).orElseThrow(() -> new ResourceNotFoundException("Tech Id " + techId + " not found"));
	}
}
