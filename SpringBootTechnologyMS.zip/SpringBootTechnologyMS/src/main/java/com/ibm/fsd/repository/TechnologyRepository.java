package com.ibm.fsd.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibm.fsd.model.Technology;


public interface TechnologyRepository extends JpaRepository<Technology, Long> {
	
	@Query(value = "SELECT t FROM technology t")
	List<Technology> findAll();
	
	@Query(value = "SELECT t FROM technology t where t.name=:name")
	List<Technology> findByName(String name);
}
