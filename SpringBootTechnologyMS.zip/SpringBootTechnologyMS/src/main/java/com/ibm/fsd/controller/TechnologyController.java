package com.ibm.fsd.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.fsd.model.Technology;
import com.ibm.fsd.service.TechnologyService;


@RestController
@RequestMapping("/tech")
public class TechnologyController {

	@Autowired
	private TechnologyService techService;

	@GetMapping("techById/{techId}")
	public Technology findTechById(@PathVariable(value = "techId", required = true) Long techId) {
		return techService.findByTechlId(techId);
	}

	@GetMapping("techByName/{techName}")
	public List<Technology> findTechByName(@PathVariable(value = "techName", required = true) String techName) {
		return techService.findByTechName(techName);
	}
	
	@GetMapping("/allTechnologies")
	public List<Technology> findAllTechnologies() {
		return techService.findAllTechnologies();
	}

	@PostMapping("/addSkill")
	public ResponseEntity<?> addTech(@RequestBody Technology tech) {
		techService.addTechnology(tech);
		return ResponseEntity.ok("Technology added successfully");
	}

	@PutMapping("/updateTech/{techId}")
	public ResponseEntity<?> updateTech(@PathVariable(value = "techId", required = true) Long techId, @Valid @RequestBody Technology tech) {
		techService.updateTechnology(techId, tech);
		return ResponseEntity.ok("Technology updated successfully");
	}

	@DeleteMapping("/deleteTech/{TechIds}")
	public ResponseEntity<?> deleteSkill(@PathVariable(value = "TechIds", required = true) String TechIds) {

		StringBuffer sb = new StringBuffer("");
		List<Long> techList = Arrays.stream(TechIds.split(",")).map(Long::parseLong).collect(Collectors.toList());
		for (Long techlId : techList) {
			techService.deleteTechnology(techlId);
			sb.append("Tech Id " + techlId + "delete successfully");
		}
		return ResponseEntity.ok(sb.toString());
	}

}