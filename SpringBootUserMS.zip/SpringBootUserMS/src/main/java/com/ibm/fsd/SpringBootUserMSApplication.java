package com.ibm.fsd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
/*
INSERT INTO roles(name) VALUES('ROLE_USER');
INSERT INTO roles(name) VALUES('ROLE_PM');
INSERT INTO roles(name) VALUES('ROLE_ADMIN');
 */
@CrossOrigin(origins = "*", maxAge = 3600)
@SpringBootApplication
public class SpringBootUserMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserMSApplication.class, args);
	}
}
