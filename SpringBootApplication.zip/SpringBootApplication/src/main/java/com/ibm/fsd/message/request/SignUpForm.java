package com.ibm.fsd.message.request;

import java.util.Set;

import javax.validation.constraints.*;
import org.hibernate.annotations.NaturalId;

public class SignUpForm {
	
	@NotBlank
    @Size(min=1, max = 50)
	private String firstName;

	@NotBlank
    @Size(min=1, max = 50)
	private String lastName;
	
	@NotBlank
    @Size(min=3, max = 50)
	private String username;

	@NaturalId
    @NotBlank
    @Size(max = 50)
    @Email
    private String email;

    @NotBlank
    @Size(min=6, max = 100)
    private String password;

    @NotNull
	private Long contactNumber;

    @NotBlank
    @Size(min=1, max = 50)
	private String userType;

	@NotBlank
    @Size(min=6, max = 100)
	private String linkedinURL;
	
	@NotNull
	private Long  yearsOfExp;

	private Set<String> role;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getLinkedinURL() {
		return linkedinURL;
	}

	public void setLinkedinURL(String linkedinURL) {
		this.linkedinURL = linkedinURL;
	}

	public Long getYearsOfExp() {
		return yearsOfExp;
	}

	public void setYearsOfExp(Long yearsOfExp) {
		this.yearsOfExp = yearsOfExp;
	}

	public Set<String> getRole() {
		return role;
	}

	public void setRole(Set<String> role) {
		this.role = role;
	}
}