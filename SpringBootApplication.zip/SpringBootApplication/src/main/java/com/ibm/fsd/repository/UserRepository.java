package com.ibm.fsd.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.fsd.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);

    @Query("SELECT p FROM User p WHERE p.username = :username and p.isActive = :isActive")
    List<User> isUserActive(@Param("username") String username, @Param("isActive") String isActive);
    
    @Transactional
    @Modifying
    @Query("UPDATE User u SET u.isActive ='Y' where u.username=:username")
    int updateIsActive(@Param("username") String username);
}