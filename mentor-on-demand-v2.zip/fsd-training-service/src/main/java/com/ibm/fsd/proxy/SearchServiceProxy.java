package com.ibm.fsd.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.ibm.fsd.model.MentorSkillsDtls;

@FeignClient(name = "fsd-search-service")
@RibbonClient(name = "fsd-search-service")
public interface SearchServiceProxy {

	@PostMapping("/search/addCalendarEntry/{mentorId}/{skillId}/{startDate}/{endDate}/{startTime}/{endTime}")
	public void addCalendarEntry(
			@RequestHeader("Authorization") String authorizationToken,
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "skillId", required = true) Long skillId,
			@PathVariable(value = "startDate", required = true) String startDate,
			@PathVariable(value = "endDate", required = true) String endDate,
			@PathVariable(value = "startTime", required = true) String startTime,
			@PathVariable(value = "endTime", required = true) String endTime);

	@GetMapping("/search/findByMentorIdSkillId/{mentorId}/{skillId}")
	public MentorSkillsDtls findByMentorIdSkillId(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "skillId", required = true) Long skillId);

	
	@PutMapping("/search/updateMentorTrainingCount/{mentorId}/{skillId}")
	public void updateMentorTrainingCount(
			@RequestHeader("Authorization") String authorizationToken,
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "skillId", required = true) Long skillId);
}