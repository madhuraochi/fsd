package com.ibm.fsd.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.fsd.entity.Training;
import com.ibm.fsd.exception.PaginationSortingException;
import com.ibm.fsd.model.Constants;
import com.ibm.fsd.model.Constants.TrainingStatus;
import com.ibm.fsd.model.TrainingDtls;
import com.ibm.fsd.pagination.Direction;
import com.ibm.fsd.pagination.OrderBy;
import com.ibm.fsd.service.TrainingService;


@RestController
@RequestMapping("/training")
public class TrainingController {

	@Autowired
	private TrainingService trainingService;

	@GetMapping("/findAllTrainings")
	public Page<TrainingDtls> findAllTrainings(
			 @RequestParam(value = "orderBy", required = true) String orderBy,
			 @RequestParam(value = "direction", required = true) String direction,
			 @RequestParam(value = "page", required = true) int page,
			 @RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.NAME.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		return trainingService.findAllTrainings(orderBy, direction, page, size);
	}

	@GetMapping("/findByMentorIdSkillId/{mentorId}/{skillId}")
	public Page<TrainingDtls> findByMentorIdSkillId(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "skillId", required = true) Long skillId,
			@RequestParam(value = "orderBy", required = true) String orderBy,
			@RequestParam(value = "direction", required = true) String direction,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		return trainingService.findByMentorIdSkillId(mentorId, skillId, orderBy, direction, page, size);
	}

	@GetMapping("/findProposedTrainings/{mentorId}")
	public Page<TrainingDtls> findProposedTrainings(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@RequestParam(value = "orderBy", required = true) String orderBy,
			@RequestParam(value = "direction", required = true) String direction,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		return trainingService.findProposedTrainings(mentorId, orderBy, direction, page, size);
	}

	@GetMapping("/findByUserIdAndStatus/{userId}/{status}")
	public Page<TrainingDtls> findTrainingByUserIdAndStatus(
			@PathVariable(value = "userId", required = true) Long userId,
			@PathVariable(value = "status", required = true) String status,
			@RequestParam(value = "orderBy", required = true) String orderBy,
			@RequestParam(value = "direction", required = true) String direction,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		List<String> trainingStatus = new ArrayList<String>();
		if (status.equals(TrainingStatus.INPROGRESS.getStatus())) {
			for (String str : Constants.getInProgress())
				trainingStatus.add(str);
		} else if (status.indexOf(";") != -1) {
			for (String item : status.split(";"))
				trainingStatus.add(item);
		} else
			trainingStatus.add(status);

		return trainingService.findByUserIdAndStatus(userId, trainingStatus, orderBy, direction, page, size);
	}

	@GetMapping("/findByMentorIdAndStatus/{mentorId}/{status}")
	public Page<TrainingDtls> findTrainingByMentorIdAndStatus(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "status", required = true) String status,
			@RequestParam(value = "orderBy", required = true) String orderBy,
			@RequestParam(value = "direction", required = true) String direction,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.USERID.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		List<String> trainingStatus = new ArrayList<String>();
		if (status.equals(TrainingStatus.INPROGRESS.getStatus())) {
			for (String str : Constants.getInProgress())
				trainingStatus.add(str);
		} else if (status.indexOf(";") != -1) {
			for (String item : status.split(";"))
				trainingStatus.add(item);
		} else
			trainingStatus.add(status);

		return trainingService.findByMentorIdAndStatus(mentorId, trainingStatus, orderBy, direction, page, size);
	}

	@PostMapping("/findAvgRating/{mentorId}/{skillId}/")
	public List<TrainingDtls> findAvgRating(
			@PathVariable(value = "mentorId", required = true) Long mentorId, 
			@PathVariable(value = "skillId", required = true) Long skillId) {
		
		return trainingService.findAvgRating(mentorId,skillId);
	}
	
	@GetMapping("/findById/{id}")
	public Training findById(
			 @PathVariable(value = "id", required = true) Long id) {
		return trainingService.findById(id);
	}

	@PostMapping("/proposeTraining")
	public ResponseEntity<?> proposeTraining(
		@Valid @RequestBody Training training) {

		trainingService.proposeTraining(training);
		return ResponseEntity.ok("Training proposal sent successfully");
	}

	@PutMapping("/approveTraining/{id}/{status}")
	public ResponseEntity<?> approveTraining(
			@PathVariable(value = "id", required = true) Long id,
			@PathVariable(value = "status", required = true) String status,
			@RequestHeader("Authorization") String authToken) {

		Training training = new Training();
		training.setStatus(status);
		trainingService.updateTraining(id, training, authToken);
		return ResponseEntity.ok("Training approved successfully");
	}

	@PutMapping("/updateTraining/{trainingId}")
	public ResponseEntity<?> updateTraining(
			@PathVariable(value = "trainingId", required = true) Long trainingId,
			@Valid @RequestBody Training training,
			@RequestHeader("Authorization") String authToken) {
		
		trainingService.updateTraining(trainingId, training, authToken);
		
		return ResponseEntity.ok("Training updated successfully");
	}

	@DeleteMapping("/deleteTraining/{id}")
	public ResponseEntity<?> deleteTraining(
		@PathVariable(value = "id", required = true) Long id) {

		trainingService.deleteTraining(id);
		return ResponseEntity.ok("Training updated successfully");
	}
}