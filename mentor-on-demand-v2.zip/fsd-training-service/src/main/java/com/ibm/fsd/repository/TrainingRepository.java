package com.ibm.fsd.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ibm.fsd.entity.Training;


public interface TrainingRepository extends JpaRepository<Training, Long> {

	@Query(value = "SELECT t FROM Training t")
	Page<Training> findAll(Pageable pageable);
	
	@Query(value = "SELECT t FROM Training t WHERE t.mentorId=?1 AND t.status='PROPOSED'")
	Page<Training> findProposedTrainings(Long mentorId, Pageable pageable);

	@Query(value = "SELECT t FROM Training t WHERE t.mentorId=?1 AND t.skillId=?2")
	Page<Training> findByMentorIdSkillId(Long mentorId, Long skillId, Pageable pageable);
	
	@Query(value = "SELECT t FROM Training t WHERE t.userId=?1 AND upper(t.status) IN (?2)")
	Page<Training> findByUserIdAndStatus(Long userId, List<String> trainingStatus, Pageable pageable);
	
	@Query(value = "SELECT t FROM Training t WHERE t.mentorId=?1 AND upper(t.status) IN (?2)")
	Page<Training> findByMentorIdAndStatus(Long mentorId, List<String> trainingStatus, Pageable pageable);
	
	@Query(value= "SELECT avg(rating) FROM Training t WHERE t.mentorId=?1 AND t.skillId=?2")
	List<Training >findAvgRating(Long mentorId, Long skillId);

	@Query(value = "SELECT t FROM Training t WHERE t.status NOT IN (?1) AND CURDATE() > t.endDate")
	List<Training> findExpiredTrainings(List<String> trainingStatus);
	
	@Query(value = "SELECT t FROM Training t where t.amountReceived != 0.0 AND t.status IN (?1) AND t.startDate > CURDATE() AND t.endDate < CURDATE()")
	List<Training> findByTrainingStatus(List<String> trainingStatus);
	
	@Query(value = "SELECT t.* FROM trainings t " 
    + "WHERE t.userId=?1 "
	+ "AND t.mentorId=?2 "
	+ "AND t.skillId=?3 "
	+ "AND (t.start_date BETWEEN ?4 AND ?5 AND t.end_date BETWEEN ?4 AND ?5) AND "
	+ "	     (t.start_time BETWEEN ?6 AND ?7 AND t.end_time BETWEEN ?6 AND ?7) ", 
	nativeQuery = true)
Training findRegisteredTraining(Long userId, Long mentorId, Long skillId, String startDate, String endDate,
	String startTime, String endTime);
}
