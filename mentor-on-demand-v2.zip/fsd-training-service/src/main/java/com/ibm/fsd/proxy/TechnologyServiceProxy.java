package com.ibm.fsd.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ibm.fsd.model.SkillDtls;

@FeignClient(name = "fsd-technology-service")
@RibbonClient(name = "fsd-technology-service")
public interface TechnologyServiceProxy {

	@GetMapping("/skills/findById/{skillId}")
	public SkillDtls findById(
			@PathVariable(value = "skillId", required = true) Long skillId);

}