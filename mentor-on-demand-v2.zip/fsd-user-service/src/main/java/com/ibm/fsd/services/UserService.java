package com.ibm.fsd.services;

import java.util.Date;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.fsd.entity.User;
import com.ibm.fsd.exception.DataValidationException;
import com.ibm.fsd.exception.ResourceExistException;
import com.ibm.fsd.exception.ResourceNotFoundException;
import com.ibm.fsd.exception.ServiceUnavailableException;
import com.ibm.fsd.model.Constants.UserRole;
import com.ibm.fsd.model.UserDtls;
import com.ibm.fsd.repository.UserRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional(readOnly = true)
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailService emailService;
	
	@Value("${server.port}")
	private String serverPort;
	
	@HystrixCommand(fallbackMethod = "fallback_findByUserIdPassword", commandKey = "findByUserIdPassword", groupKey = "findByUserIdPassword", ignoreExceptions = {
			UsernameNotFoundException.class })
	public User findByUserIdPassword(String userName, String password) {
		PasswordEncoder encoder = new BCryptPasswordEncoder(4);
		User user = userRepository.findByConfirmedUser(userName);
		if (null == user || (null != user && !encoder.matches(password, user.getPassword())))
			throw new UsernameNotFoundException("Invalid Credential or Confirmation Pending or User blocked or Forced Reset Password.");
		return user;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_signup", commandKey = "signup", groupKey = "signup", ignoreExceptions = {
			DataValidationException.class, ResourceExistException.class })
	public User signup(User user) {

		if (null == user.getRole() || (null != user.getRole() && user.getRole().length() == 0))
			throw new DataValidationException("User role is compulsery");

		if (!(user.getRole().toUpperCase().equals(UserRole.ROLE_ADMIN.getRole())
				|| user.getRole().toUpperCase().equals(UserRole.ROLE_USER.getRole())
				|| user.getRole().toUpperCase().equals(UserRole.ROLE_MENTOR.getRole()))) {
			throw new DataValidationException("Invalid user Type " + user.getRole());
		}

		if (user.getRole().toUpperCase().equals(UserRole.ROLE_ADMIN.getRole())
				|| user.getRole().toUpperCase().equals(UserRole.ROLE_USER.getRole())) {
			user.setLinkedinUrl(null);
			user.setYearsOfExperience(null);
		} else if (user.getRole().toUpperCase().equals(UserRole.ROLE_MENTOR.getRole())) {
			if (null == user.getLinkedinUrl()
					|| (null != user.getLinkedinUrl() && user.getLinkedinUrl().trim().length() == 0))
				throw new DataValidationException("Mentor should have linkedlin URL");
			if (null == user.getYearsOfExperience()
					|| (null != user.getYearsOfExperience() && user.getYearsOfExperience().floatValue() == 0.0f))
				throw new DataValidationException("Mentor should have years of experience");
		}

		if (null != userRepository.findByName(user.getUserName()))
			throw new ResourceExistException("User Name " + user.getUserName() + " already Exists");

		Random r = new Random();
		String token = Long.toString(Math.abs(r.nextLong()), 36);
		PasswordEncoder pencoder = new BCryptPasswordEncoder(4);
		user.setPassword(pencoder.encode(user.getPassword()));
		user.setRegCode(token);
		userRepository.save(user);
		
		String subject = "Active your account";
		String text = "Hi " + user.getFirstName() + ",<br><br>Click on below link to confirm signup.<br><br>"
				+ "http://localhost:"+serverPort+"/confirmUser?un="+user.getUserName()+"&tn="+token;
		emailService.sendMail("JavaCapsuleProgram@test.com", user.getUserName(), subject, text);
		
		return user;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_confirmUser", commandKey = "confirmUser", groupKey = "confirmUser")
	public String confirmUser(UserDtls userDtls) {

		String message = "";
		User user = userRepository.findByConfirmedUser(userDtls.getUserName());
		if (null != user)
			message = userDtls.getUserName() +" already confirmed";
		else {			
			user = userRepository.findUserByNameRegCodeForSignUp(userDtls.getUserName(), userDtls.getToken());
			if (null == user)
				message = "Invalid User Name or Token or Signup token expired";
			else {
				user.setRegCode("");
				user.setActive(true);
				user.setConfirmedSignUp(true);
				userRepository.save(user);
				message = "Signup confirmation successful. Thanks";
			}
		}
		return message;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_forgetPassword", commandKey = "forgetPassword", groupKey = "forgetPassword", ignoreExceptions = {
			ResourceNotFoundException.class })
	public void forgetPassword(String userName) {

		User user = userRepository.findByConfirmedUser(userName);
		if (null == user)
			throw new ResourceNotFoundException("User Name " + userName + " not found");
		
		Random r = new Random();
		String token = Long.toString(Math.abs(r.nextLong()), 36);
		user.setRegCode(token);
		user.setResetPasswordDate(new Date());
		user.setResetPassword(true);
		userRepository.save(user);

		String subject = "Reset your new password";
		String text = "Hi " + user.getFirstName() + ",<br><br>Please click on below link to reset password. Reset password token will active for next 15 minutes.<br><br>"
				+ "http://localhost:"+serverPort+"/resetPassword?un="+user.getUserName()+"&tn="+token;
		emailService.sendMail("MentorOnDemand@test.com", user.getUserName(), subject, text);
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_resetPassword", commandKey = "resetPassword", groupKey = "resetPassword", ignoreExceptions = {
			ResourceNotFoundException.class })
	public String resetPassword(UserDtls userDtls) {

		String message = "";
		User user = userRepository.findByConfirmedUser(userDtls.getUserName());
		if (null != user)
			message = "Password already reset for " + userDtls.getUserName();
		else {
			user = userRepository.findUserByNameRegCodeForPwdReset(userDtls.getUserName(), userDtls.getToken());
			if (null == user)
				message = "Invalid User Name or Token or Reset password token expired";
			else {
				PasswordEncoder pencoder = new BCryptPasswordEncoder(4);
				user.setPassword(pencoder.encode(userDtls.getPassword()));
				user.setRegCode("");
				user.setResetPasswordDate(null);
				user.setResetPassword(false);
				userRepository.save(user);
				message = "Password reset successfully";
			}
		}
		return message;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_updateProfile", commandKey = "updateProfile", groupKey = "updateProfile", ignoreExceptions = {
			ResourceNotFoundException.class })
	public User updateProfile(Long userId, User user) {
		
		return userRepository.findById(userId).map(oldUser -> {
			// block or unblock user
			if (!user.getActive().equals(oldUser.getActive()))
				oldUser.setActive(user.getActive());
			else {
				if (null != user.getPassword() && user.getPassword().trim().length() > 0) {
					PasswordEncoder pencoder = new BCryptPasswordEncoder(4);
					oldUser.setPassword(pencoder.encode(user.getPassword()));
				}
				if (null != user.getFirstName() && user.getFirstName().trim().length() > 0)
					oldUser.setFirstName(user.getFirstName());
				if (null != user.getLastName() && user.getLastName().trim().length() > 0)
					oldUser.setLastName(user.getLastName());
				if (null != user.getContactNumber() && user.getContactNumber().longValue() != 0L)
					oldUser.setContactNumber(user.getContactNumber());
				if (oldUser.getRole().toUpperCase().equals(UserRole.ROLE_MENTOR.getRole())) {
					if (null != user.getLinkedinUrl() && user.getLinkedinUrl().trim().length() > 0)
						oldUser.setLinkedinUrl(user.getLinkedinUrl());
					if (null != user.getRegCode())
						oldUser.setRegCode(user.getRegCode());
					if (null != user.getYearsOfExperience() && user.getYearsOfExperience() != 0.0f)
						oldUser.setYearsOfExperience(user.getYearsOfExperience());
				}
			}
			return userRepository.save(oldUser);
		}).orElseThrow(() -> new ResourceNotFoundException("UserId " + userId + " not found"));
	}

	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_deleteProfile", commandKey = "deleteProfile", groupKey = "deleteProfile", ignoreExceptions = {
			ResourceNotFoundException.class })
	public void deleteProfile(Long userId) {

		userRepository.findById(userId).map(user -> {
			userRepository.delete(user);
			return true;
		}).orElseThrow(() -> new ResourceNotFoundException("UserId " + userId + " not found"));
	}

	@SuppressWarnings("deprecation")
	@HystrixCommand(fallbackMethod = "fallback_findAllUsers", commandKey = "findAllUsers", groupKey = "findAllUsers", ignoreExceptions = {
			ResourceNotFoundException.class })
	public Page<User> findAllUsers(String orderBy, String direction, int page, int size) {
		
		Sort sort = null;

		if ("ASC".equals(direction)) {
			sort = new Sort(new Sort.Order(Direction.ASC, orderBy));
		} else if ("DESC".equals(direction)) {
			sort = new Sort(new Sort.Order(Direction.DESC, orderBy));
		}
		Pageable pageable = new PageRequest(page, size, sort);
		return userRepository.findAll(pageable);
	}

	@HystrixCommand(fallbackMethod = "fallback_findById", commandKey = "findById", groupKey = "findById", ignoreExceptions = {
			ResourceNotFoundException.class })
	public User findById(Long userId) {

		return Optional.ofNullable(userRepository.findById(userId).get())
					.orElseThrow(() -> new ResourceNotFoundException("User Id " + userId + " not found"));
	}

	@HystrixCommand(fallbackMethod = "fallback_findByName", commandKey = "findByName", groupKey = "findByName", ignoreExceptions = {
			ResourceNotFoundException.class })
	public User findByName(String userName) {
		return Optional.ofNullable(userRepository.findByName(userName))
					.orElseThrow(() -> new ResourceNotFoundException("User Name " + userName + " not found"));
	}

	/*list of fallback methods for @HystrixCommand*/
	public User fallback_findByUserIdPassword(String userName, String password) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public User fallback_signup(User user) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public String fallback_confirmUser(UserDtls userDtls) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_forgetPassword(String userName) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public String fallback_resetPassword(UserDtls userDtls) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public User fallback_updateProfile(Long userId, User user) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public void fallback_deleteProfile(Long userId) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public Page<User> fallback_findAllUsers(String orderBy, String direction, int page, int size) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public User fallback_findById(Long userId) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public User fallback_findByName(String userName) {
		throw new ServiceUnavailableException("Service Unavailable");
	}
}
