package com.ibm.fsd.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ibm.fsd.entity.Technology;


public interface TechnologyRepository extends PagingAndSortingRepository<Technology, Long> {
	
	@Query(value = "SELECT s FROM Technology s")
	Page<Technology> findAll(Pageable pageable);
	
	@Query(value = "SELECT s FROM Technology s WHERE LOWER(name)=?1")
	public Technology findByName(String skillName);
	
	@Query(value = "SELECT s FROM Technology s WHERE LOWER(name) like ?1%")
	public List<Technology> findByLikeName(String name);
}
