package com.ibm.fsd.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ibm.fsd.entity.AuditModel;

@Entity
@Table(name = "payments")
public class Payments extends AuditModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "mentor_id", nullable = true)
	private Long mentorId;

	@Column(name = "training_id", nullable = true)
	private Long trainingId;

	@Column(name = "txn_type", nullable = true)
	private String txnType;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "txn_date", nullable = true)
	private Date txnDate;

	@Column(name = "txn_status", nullable = true)
	private String txnStatus;

	@Column(name = "amount_to_mentor", nullable = false)
	private Float amountToMentor;

	@Column(name = "remarks", nullable = false)
	private String remarks;
	
	
	public Payments() {
		super();
	}
	
	public Payments(Long mentorId, Long trainingId, String txnType, Date txnDate, String txnStatus, Float amountToMentor, String remarks) {
		super();
		this.mentorId = mentorId;
		this.trainingId = trainingId;
		this.txnType = txnType;
		this.txnDate = txnDate;
		this.txnStatus = txnStatus;
		this.amountToMentor = amountToMentor;
		this.remarks = remarks;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public Long getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(Long trainingId) {
		this.trainingId = trainingId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Date getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public Float getAmountToMentor() {
		return amountToMentor;
	}

	public void setAmountToMentor(Float amountToMentor) {
		this.amountToMentor = amountToMentor;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}