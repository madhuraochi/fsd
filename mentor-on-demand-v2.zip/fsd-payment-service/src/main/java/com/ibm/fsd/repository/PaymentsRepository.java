package com.ibm.fsd.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ibm.fsd.entity.Payments;

public interface PaymentsRepository extends JpaRepository<Payments, Long> {}
