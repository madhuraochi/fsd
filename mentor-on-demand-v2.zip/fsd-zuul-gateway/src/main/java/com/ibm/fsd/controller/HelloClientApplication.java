package com.ibm.fsd.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.ibm.fsd.exception.ServiceUnavailableException;
import com.ibm.fsd.model.UserDtls;
import com.ibm.fsd.proxy.UserServiceProxy;
import com.ibm.fsd.util.Translator;

@RestController
public class HelloClientApplication {

	@Autowired
	private UserServiceProxy userProxy;

	@GetMapping("/findByName/{userName}")
	public UserDtls findByName(
			@PathVariable(value = "userName", required = true) String userName) {
		UserDtls userDtlsObj = userProxy.findByName(userName);
		if (userDtlsObj == null)
			throw new ServiceUnavailableException(Translator.toLocale("error.service.unavailable", "fsd-user-service"));
		else
			return userDtlsObj;
	}
}
