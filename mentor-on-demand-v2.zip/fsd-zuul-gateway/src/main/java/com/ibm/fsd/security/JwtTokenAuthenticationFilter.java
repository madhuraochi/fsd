package com.ibm.fsd.security;

import static com.ibm.fsd.model.Constants.AUTHORITIES_KEY;
import static com.ibm.fsd.model.Constants.HEADER_STRING;
import static com.ibm.fsd.model.Constants.SIGNING_KEY;
import static com.ibm.fsd.model.Constants.TOKEN_PREFIX;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.filter.OncePerRequestFilter;
import com.ibm.fsd.util.Translator;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;

public class JwtTokenAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
    private UserDetailsService userDetailsService;
	
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		// Get the authentication header
		String header = request.getHeader(HEADER_STRING);
		// Validate the header and check the prefix
		if (header == null || !header.startsWith(TOKEN_PREFIX)) {
			chain.doFilter(request, response);
			return;
		}
		// Get the token
		String authToken = header.replace(TOKEN_PREFIX, "");
		String userName = null;
		
		try {
			// Validate the token otherwise throw ExpiredJwtException
			Claims claims = Jwts.parser().setSigningKey(SIGNING_KEY).parseClaimsJws(authToken).getBody();
			userName = claims.getSubject();
			if (userName != null && SecurityContextHolder.getContext().getAuthentication() == null) {
				UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
				UsernamePasswordAuthenticationToken authentication = getAuthentication(authToken, SecurityContextHolder.getContext().getAuthentication(), userDetails);
				logger.info("authenticated user " + userName + ", setting security context");
                SecurityContextHolder.getContext().setAuthentication(authentication);
				/*@SuppressWarnings("unchecked")
				List<String> authorities = (List<String>) claims.get("authorities");
				UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(userName, null,
						authorities.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
				SecurityContextHolder.getContext().setAuthentication(auth);*/
			}
		} catch (IllegalArgumentException e) {
			// logger.error("an error occured during getting username from token", e);
		} catch (ExpiredJwtException e) {
			request.setAttribute("expired", Translator.toLocale("error.token.expired"));
			// logger.warn("the token is expired and not valid anymore", e);
		} catch (SignatureException e) {
			// logger.error("Authentication Failed. Username or Password not valid.");
		} catch (Exception e) {
			SecurityContextHolder.clearContext();
		}
		
		chain.doFilter(request, response);
	}

	
	UsernamePasswordAuthenticationToken getAuthentication(final String token, final Authentication existingAuth,
			final UserDetails userDetails) {

		final JwtParser jwtParser = Jwts.parser().setSigningKey(SIGNING_KEY);
		final Jws<Claims> claimsJws = jwtParser.parseClaimsJws(token);
		final Claims claims = claimsJws.getBody();
		final Collection<? extends GrantedAuthority> authorities = Arrays
				.stream(claims.get(AUTHORITIES_KEY).toString().split(",")).map(SimpleGrantedAuthority::new)
				.collect(Collectors.toList());
		return new UsernamePasswordAuthenticationToken(userDetails, "", authorities);
	}
}