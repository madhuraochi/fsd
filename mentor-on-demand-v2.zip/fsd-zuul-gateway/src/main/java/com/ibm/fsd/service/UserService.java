package com.ibm.fsd.service;

import java.util.HashSet;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.ibm.fsd.model.UserDtls;
import com.ibm.fsd.proxy.UserServiceProxy;
import com.ibm.fsd.util.Translator;

@Service(value = "userService")
public class UserService implements UserDetailsService {

	@Autowired
	private UserServiceProxy userProxy;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		UserDtls user = userProxy.findByName(userName);
		if (user == null || (user != null && (!user.getConfirmedSignUp().booleanValue()
				|| !user.getActive().booleanValue() || !user.getResetPassword().booleanValue())))
			throw new UsernameNotFoundException(Translator.toLocale("error.invalid.user"));
		else
			return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), getAuthority(user.getRole()));
	}

	private Set<SimpleGrantedAuthority> getAuthority(String role) {
		Set<SimpleGrantedAuthority> authorities = new HashSet<SimpleGrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
		return authorities;
	}
}