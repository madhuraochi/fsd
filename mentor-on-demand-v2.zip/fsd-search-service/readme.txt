create schema mentor_service;
use mentor_service;


User Name   					Password
--------------------------------------------
arnabmca2006@rediffmail.com		sureshkumar
amit_kumar@gmail.com			amitkumar