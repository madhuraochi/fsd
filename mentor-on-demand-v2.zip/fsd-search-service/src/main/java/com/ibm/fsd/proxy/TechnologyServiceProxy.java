package com.ibm.fsd.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ibm.fsd.exception.ResourceNotFoundException;
import com.ibm.fsd.model.SkillDtls;
import com.ibm.fsd.proxy.TechnologyServiceFallback;
import com.ibm.fsd.proxy.TechnologyServiceProxy;

@FeignClient(value = "fsd-technology-service", fallback = TechnologyServiceFallback.class)
@RibbonClient(value = "fsd-technology-service")
public interface TechnologyServiceProxy {

	@GetMapping("/skills/findById/{skillId}")
	public SkillDtls findById(
			@PathVariable(value = "skillId", required = true) Long skillId) throws ResourceNotFoundException;

}

@Component
class TechnologyServiceFallback implements TechnologyServiceProxy {

	@Override
	public SkillDtls findById(Long skillId) {
		return null;
	}
}
