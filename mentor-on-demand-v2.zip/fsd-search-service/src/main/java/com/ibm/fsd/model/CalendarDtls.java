package com.ibm.fsd.model;

public interface CalendarDtls {

	public String getUserName();

	public String getMentorName();

	public String getSkillName();

	public String getStartdate();

	public String getEnddate();

	public String getStarttime();

	public String getEndtime();

}
