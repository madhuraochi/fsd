package com.ibm.fsd.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.fsd.exception.PaginationSortingException;
import com.ibm.fsd.entity.MentorSkills;
import com.ibm.fsd.model.MentorSkillsDtls;
import com.ibm.fsd.service.MentorSkillsService;
import com.ibm.fsd.pagination.Direction;
import com.ibm.fsd.pagination.OrderBy;

import io.swagger.annotations.ApiParam;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/search")
public class MentorSkillsController {

	@Autowired
	private MentorSkillsService mentorSkillService;

	@GetMapping("/findBySkillIdDateRange/{skillId}/{startDate}/{endDate}/{startTime}/{endTime}")
	public Page<MentorSkillsDtls> findBySkillIdDateRange(@PathVariable(value = "skillId", required = true) Long skillId,
			@PathVariable(value = "startDate", required = true) String startDate,
			@PathVariable(value = "endDate", required = true) String endDate,
			@PathVariable(value = "startTime", required = true) String startTime,
			@PathVariable(value = "endTime", required = true) String endTime,
			@RequestParam(value = "orderBy", required = true) String orderBy,
			@RequestParam(value = "direction", required = true) String direction,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.NAME.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		return mentorSkillService.findBySkillIdDateRange(skillId, startDate, endDate, startTime, endTime, orderBy,
				direction, page, size);
	}

	@GetMapping("/findByMentorId/{mentorId}")
	public Page<MentorSkillsDtls> findByMentorId(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@RequestParam(value = "orderBy", required = true) String orderBy,
			@RequestParam(value = "direction", required = true) String direction,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "size", required = true) int size) {

		if (!(direction.equals(Direction.ASCENDING.getDirectionCode())
				|| direction.equals(Direction.DESCENDING.getDirectionCode()))) {
			throw new PaginationSortingException("Invalid sort direction");
		}
		if (!(orderBy.equals(OrderBy.ID.getOrderByCode()) || orderBy.equals(OrderBy.NAME.getOrderByCode()))) {
			throw new PaginationSortingException("Invalid orderBy condition");
		}

		return mentorSkillService.findByMentorId(mentorId, orderBy, direction, page, size);
	}

	@GetMapping("/findByMentorIdSkillId/{mentorId}/{skillId}")
	public MentorSkills findByMentorIdSkillId(@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "skillId", required = true) Long skillId) {

		return mentorSkillService.findByMentorIdSkillId(mentorId, skillId);

	}

	@PostMapping("/addMentorSkill")
	public ResponseEntity<?> addMentorSkill(
		@Valid @RequestBody MentorSkills mentorSkill) {
		
		mentorSkillService.addMentorSkill(mentorSkill);
		return ResponseEntity.ok("Mentor skill added successfully");
		

	}

	@PutMapping("/updateMentorSkill/{id}")
	public ResponseEntity<?> updateMentorSkill(
			@ApiParam(value = "Mentor Skill Id for which record needs to update", required = true) @PathVariable(value = "id", required = true) Long id,
			@ApiParam(value = "Mentor Skill details which needs to update", required = true) @Valid @RequestBody MentorSkills mentorSkill) {

		mentorSkillService.updateMentorSkill(id, mentorSkill);
		return ResponseEntity.ok("Mentor skill updated successfully");
		
	}

	@PutMapping("/updateMentorTrainingCount/{mentorId}/{skillId}")
	public void updateMentorTrainingCount(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "skillId", required = true) Long skillId) {

		mentorSkillService.updateMentorTrainingCount(mentorId, skillId);
	}

	@DeleteMapping("/deleteMentorSkill/{id}")
	public ResponseEntity<?> deleteMentorSkill(
		@PathVariable(value = "id", required = true) Long id) {

		mentorSkillService.deleteMentorSkill(id);
		
		return ResponseEntity.ok("Mentor skill deleted successfully");
	}
}