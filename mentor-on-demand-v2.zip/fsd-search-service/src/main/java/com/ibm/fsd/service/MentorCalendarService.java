package com.ibm.fsd.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.fsd.entity.MentorCalendar;
import com.ibm.fsd.exception.ResourceExistException;
import com.ibm.fsd.exception.ResourceNotFoundException;
import com.ibm.fsd.exception.ServiceUnavailableException;
import com.ibm.fsd.model.MentorCalendarDtls;
import com.ibm.fsd.model.SkillDtls;
import com.ibm.fsd.model.UserDtls;
import com.ibm.fsd.proxy.TechnologyServiceProxy;
import com.ibm.fsd.proxy.UserServiceProxy;
import com.ibm.fsd.repository.MentorCalendarRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional(readOnly = true)
public class MentorCalendarService {

	@Autowired
	private MentorCalendarRepository mentorCalendarRepository;

	@Autowired
	private TechnologyServiceProxy techProxy;

	@Autowired
	private UserServiceProxy userProxy;
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_addCalendarEntry", commandKey = "addCalendarEntry", groupKey = "addCalendarEntry", ignoreExceptions = {
			ResourceNotFoundException.class, ResourceExistException.class })
	public MentorCalendar addCalendarEntry(Long userId, Long skillId, String startDateStr, String endDateStr,
			String startTimeStr, String endTimeStr) {

		UserDtls mentor = userProxy.findById(userId);
		SkillDtls skill = techProxy.findById(skillId);

		if (null == mentor)
			throw new ResourceNotFoundException("Mentor Id " + userId + " not found");

		if (null == skill)
			throw new ResourceNotFoundException("Skill Id " + skill + " not found");

		List<MentorCalendar> calendarEntries = mentorCalendarRepository.findCalendarEntry(userId, startDateStr,
				endDateStr, startTimeStr, endTimeStr);
		if (calendarEntries.size() > 0)
			throw new ResourceExistException("Calendar entry for Mentor Id " + userId + " already entered for the period " + startDateStr
							+ " - " + endDateStr + " and " + startTimeStr + " - " + endTimeStr);

		MentorCalendar mentorCalendar = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate startDate = LocalDate.parse(startDateStr, formatter);
		LocalDate endDate = LocalDate.parse(endDateStr, formatter).plusDays(1);
		for (LocalDate date = startDate; date.isBefore(endDate); date = date.plusDays(1)) {
			mentorCalendar = new MentorCalendar();
			mentorCalendar.setStartDate(date.toString());
			mentorCalendar.setEndDate(date.toString());
			mentorCalendar.setStartTime(startTimeStr);
			mentorCalendar.setEndTime(endTimeStr);
			mentorCalendar.setMentorId(mentor.getId());
			mentorCalendar.setSkillId(skillId);
			mentorCalendarRepository.save(mentorCalendar);
		}

		return mentorCalendar;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	@HystrixCommand(fallbackMethod = "fallback_findMentorCalendarByMentorId", commandKey = "findMentorCalendarByMentorId", groupKey = "findMentorCalendarByMentorId")
	public List<MentorCalendarDtls> findMentorCalendarByMentorId(Long mentorId, String startDate, String endDate) {
		
		List<MentorCalendarDtls> mentorCalendarDtlsList = new ArrayList<>();
		MentorCalendar mentorCalendarObj = null;
		MentorCalendarDtls mentorCalendarDtlObj = null;
		SkillDtls skill = null;
		List<MentorCalendar> mentorCalendarList = mentorCalendarRepository.findMentorCalendarByMentorId(mentorId, startDate, endDate);
		for (int index = 0; index < mentorCalendarList.size(); index++) {
			mentorCalendarObj = mentorCalendarList.get(index);
			skill = techProxy.findById(mentorCalendarObj.getSkillId());
			if (null != skill) {
				mentorCalendarDtlObj = new MentorCalendarDtls();
				BeanUtils.copyProperties(mentorCalendarObj, mentorCalendarDtlObj);
				mentorCalendarDtlObj.setSkillName(skill.getName());
				mentorCalendarDtlsList.add(mentorCalendarDtlObj);
			}
		}

		return mentorCalendarDtlsList;
	}

	/*list of fallback method for @HystrixCommand*/
	public MentorCalendar fallback_addCalendarEntry(Long userId, Long skillId, String startDateStr, String endDateStr,
			String startTimeStr, String endTimeStr) {
		throw new ServiceUnavailableException("Service Unavailable");
	}

	public List<MentorCalendarDtls> fallback_findMentorCalendarByMentorId(Long mentorId, String startDate,
			String endDate) {
		throw new ServiceUnavailableException("Service Unavailable");
	}
}