package com.ibm.fsd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.fsd.model.MentorCalendarDtls;
import com.ibm.fsd.service.MentorCalendarService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/search")
public class MentorCalendarController {

	@Autowired
	private MentorCalendarService mentorCalendarService;

	@PostMapping("/addCalendarEntry/{mentorId}/{skillId}/{startDate}/{endDate}/{startTime}/{endTime}")
	public ResponseEntity<?> addCalendarEntry(
			 @PathVariable(value = "mentorId", required = true) Long mentorId, 
			 @PathVariable(value = "skillId", required = true) Long skillId,
			 @PathVariable(value = "startDate", required = true) String startDate, 
			 @PathVariable(value = "endDate", required = true) String endDate,
			 @PathVariable(value = "startTime", required = true) String startTime, 
			 @PathVariable(value = "endTime", required = true) String endTime) {
		
		mentorCalendarService.addCalendarEntry(mentorId, skillId, startDate, endDate, startTime, endTime);
		return ResponseEntity.ok("Calendar-entry added successfully");
	}
	
	@GetMapping("/findMentorCalendarByMentorId/{mentorId}/{startDate}/{endDate}")
	public List<MentorCalendarDtls> findMentorCalendarByMentorId(
			@PathVariable(value = "mentorId", required = true) Long mentorId,
			@PathVariable(value = "startDate") String startDate,
			@PathVariable(value = "endDate") String endDate) {
		
		return mentorCalendarService.findMentorCalendarByMentorId(mentorId,startDate,endDate);
	}
}