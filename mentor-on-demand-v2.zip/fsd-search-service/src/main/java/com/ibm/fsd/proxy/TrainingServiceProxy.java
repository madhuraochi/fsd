package com.ibm.fsd.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ibm.fsd.model.TrainingDtls;
import com.ibm.fsd.proxy.TrainingServiceFallback;
import com.ibm.fsd.proxy.TrainingServiceProxy;

@FeignClient(name = "fsd-training-service" , fallback = TrainingServiceFallback.class)
@RibbonClient(name = "fsd-training-service")
public interface TrainingServiceProxy {

	@PostMapping("/training/findAvgRating")
	public List<TrainingDtls> findAvgRating(
			@RequestBody List<TrainingDtls> list);

}

@Component
class TrainingServiceFallback implements TrainingServiceProxy {

	@Override
	public List<TrainingDtls> findAvgRating(List<TrainingDtls> list) {
		return new ArrayList<>();
	}
	
}