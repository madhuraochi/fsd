package com.ibm.fsd.model;

import java.util.ArrayList;

public class Constants {

	public static final long ACCESS_TOKEN_VALIDITY_SECONDS = 5 * 60 * 60;
	public static final String SIGNING_KEY = "devglan123r";
	public static final String TOKEN_PREFIX = "Bearer ";
	public static final String HEADER_STRING = "Authorization";
	public static final String AUTHORITIES_KEY = "scopes";

	public enum UserRole {

		ROLE_ADMIN("ADMIN"), ROLE_MENTOR("MENTOR"), ROLE_USER("USER");
		private final String role;

		private UserRole(String role) {
			this.role = role;
		}

		public String getRole() {
			return role;
		}
	}

	public enum ProposoalStuts {

		ACCEPT("ACCEPT"), REJECT("REJECT");
		private final String status;

		private ProposoalStuts(String status) {
			this.status = status;
		}

		public String getStatus() {
			return status;
		}
	}

	private static ArrayList<String> statusList = new ArrayList<String>(5);

	public static ArrayList<String> getStatusList() {
		Constants.statusList.add(TrainingStatus.PROPOSED.getStatus());
		Constants.statusList.add(TrainingStatus.CONFIRMED.getStatus());
		Constants.statusList.add(TrainingStatus.TRAINING_STARTED.getStatus());
		Constants.statusList.add(TrainingStatus.NOT_COMPLETED.getStatus());
		return statusList;
	}

	public enum TrainingStatus {

		INPROGRESS("INPROGRESS"), PROPOSED("PROPOSED"), CONFIRMED("CONFIRMED"), TRAINING_STARTED(
				"TRAINING-STARTED"), NOT_COMPLETED("NOT-COMPLETED"), COMPLETED("COMPLETED"), REJECTED("REJECTED");
		private final String status;

		private TrainingStatus(String status) {
			this.status = status;
		}

		public String getStatus() {
			return status;
		}
	}
}